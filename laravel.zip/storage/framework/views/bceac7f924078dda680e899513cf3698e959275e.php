
<?php $__env->startSection('content'); ?>
<section class="py-5" style="margin-top: 100px">
    <div class="container col-xxl-8">
        <h3 class="fw-bold mb-2">
            Halaman Blog Artikel
        </h3>

        <a href="<?php echo e(route('blog.create')); ?>" class="btn btn-primary" style="background-color: #144171; color: white;">Buat Artikel</a>
        <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-danger btn-sm float-left">Kembali</a>

        <!-- Pesan Sukses -->
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade-show" role="alert">
            <strong>Informasi</strong> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="table-responsive py-3">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Judul</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    ?>
                    <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td>
                            <img src="<?php echo e(asset('storage/artikel/' . $artikel->image)); ?>" height="100" alt="">
                        </td>
                        <td>
                            <?php echo e($artikel->judul); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('blog.edit', $artikel->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('blog.destroy', $artikel->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" onclick="alert('Yakin di hapus nih ?')" class="btn btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ponpes-app\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>