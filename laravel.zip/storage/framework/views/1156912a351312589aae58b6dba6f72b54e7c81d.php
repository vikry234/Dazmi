<style>
    .carousel-item::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: linear-gradient(to bottom, rgba(44, 44, 44, 0.1), rgba(44, 44, 44, 0.4));
        z-index: 1;
    }

    .carousel-caption {
        z-index: 2;
        /* Atur z-index untuk .carousel-caption agar lebih tinggi dari gradient linear */
    }
</style>

<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-bs-ride="carousel">
    <div class="carousel-inner" style="margin-top: 90px">

        <?php
        $i = 0;
        ?>
        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slideritem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php echo e($i == 0 ? 'active' : ''); ?>">
            <img src="<?php echo e(asset('uploads/slider/'.$slideritem->image)); ?>" class="d-block w-100" alt="Slider image">
            <div class="carousel-caption d-none d-md-block">
                <h1><?php echo e($slideritem->heading); ?></h1>
                <p><?php echo e($slideritem->description); ?></p>
                <a href="<?php echo e($slideritem->link); ?>"><?php echo e($slideritem->link_name); ?></a>
            </div>
        </div>
        <?php
        $i++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="carousel-indicators">
        <?php
        $j = 0;
        ?>
        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slideritem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($j); ?>" class="<?php echo e($j == 0 ? 'active' : ''); ?>"></div>
        <?php
        $j++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<script>
    $(document).ready(function() {
        $('#carouselExampleIndicators').carousel({
            interval: 3000 // Mengatur waktu putaran otomatis dalam milidetik
        });
    });
</script><?php /**PATH D:\ponpes-app\resources\views/slider/slider.blade.php ENDPATH**/ ?>