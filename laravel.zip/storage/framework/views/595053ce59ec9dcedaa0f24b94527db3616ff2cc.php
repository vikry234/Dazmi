
<style>
  .navbar-nav .nav-link {
    font-size: 10px;
    /* Atur ukuran teks untuk item menu */
  }

  .dropdown-menu a {
    font-size: 14px;
    /* Atur ukuran teks untuk item dropdown */
  }

  .navbar-nav .nav-link:hover {
    color: #144171;
    transform: scale(1.2);
    box-shadow: 50px rgba(0, 0, 0, 0.1);
  }

  .nav-link {
    position: relative;
    display: inline-block;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .dropdown-menu {
    display: none;
    position: absolute;
    background-color: white;
    z-index: 1;
    opacity: 0;
    transform: translateY(-20px);
    /* Atur posisi awal dropdown di atas */
  }

  /* Tampilkan dropdown saat item dropdown dihover */
  .navbar-nav .dropdown:hover .dropdown-menu {
    display: block;
    opacity: 1;
    transform: translateY(0);
    /* Geser dropdown ke posisi aslinya */
  }

  /* Gaya item dropdown */
  .dropdown-menu a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    transition: background-color 0.3s;
  }

  /* Gaya item dropdown saat dihover */
  .dropdown-menu a:hover {
    background-color: #f2f2f2;
  }
</style>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

<nav class="navbar shadow navbar-expand-lg mb-5 py-3 fixed-top bg-white">
  <div class="container" style="font-family: Arial, Helvetica, sans-serif;">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
      <img src="<?php echo e(asset('assets/icons/Header.png')); ?>" height="51" width="238" alt="">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">BERANDA</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle show" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            TENTANG
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?php echo e(url('/dazmi')); ?>">Profile Ponpes</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('/pimpinan')); ?>">Pimpinan</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('/kurikulum')); ?>">Pembelajaran</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('/milestone')); ?>">Milestone</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('/pengajar')); ?>">Tenaga Pengajar</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('/sarana')); ?>">Sarana & Prasarana</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="/berita">BERITA</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="<?php echo e(url('/gallery')); ?>">GALLERY</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="<?php echo e(url('/youtube')); ?>">VIDEO</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="<?php echo e(url('/kontak')); ?>">KONTAK</a>
        </li>
      </ul>
      <form class="d-flex" action="<?php echo e(route('search')); ?>" method="GET">
        <input class="form-control me-2" type="search" placeholder="Cari..." aria-label="Search" name="query">
        <button class="btn btn-outline-primary" type="submit">Cari</button>
      </form>
    </div>
  </div>
</nav>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    const dropdownToggles = document.querySelectorAll(".dropdown-toggle");

    dropdownToggles.forEach(function(toggle) {
      toggle.addEventListener("click", function() {
        const parent = this.parentElement;
        const dropdownMenu = parent.querySelector(".dropdown-menu");

        // Toggle visibility of dropdown menu
        if (dropdownMenu.style.display === "block") {
          dropdownMenu.style.display = "none";
        } else {
          dropdownMenu.style.display = "block";
        }
      });
    });
  });
</script>

<?php /**PATH D:\ponpes-app\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>