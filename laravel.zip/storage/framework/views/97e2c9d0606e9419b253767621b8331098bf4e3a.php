
<?php $__env->startSection('content'); ?>
<section style="margin-top: 100px">
    <div class="container col-xxl-8 py-5">
        <h3 class="fw-bold mb-2">
            Halaman Dashboard Admin
        </h3>
        <p>Selamat datang di halaman dashboard admin</p>

        <div class="row">
            <div class="col-lg-4">
                <div class="card shadow-sm rounded-3 border-0">
                    <img src="<?php echo e(asset('assets/images/banner2.jpg')); ?>" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Blog Artikel</h5>
                        <p class="card-text">Atur dan kelola artikel kegiatan pesantren.</p>
                        <div class="text-center">
                            <a href="<?php echo e(route('blog')); ?>" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card shadow-sm rounded-3 border-0">
                    <img src="<?php echo e(asset('assets/images/banner4.jpg')); ?>" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Foto Kegiatan</h5>
                        <p class="card-text">Atur dan kelola Foto kegiatan pesantren.</p>
                        <div class="text-center">
                            <a href="<?php echo e(route('photo')); ?>" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card shadow-sm rounded-3 border-0">
                    <img src="<?php echo e(asset('assets/images/banner3.jpg')); ?>" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Video Kegiatan</h5>
                        <p class="card-text">Atur dan kelola Video kegiatan pesantren.</p>
                        <div class="text-center">
                            <a href="<?php echo e(route('video')); ?>" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 pt-5">
                <div class="card shadow-sm rounded-3 border-0">
                    <img src="<?php echo e(asset('assets/images/banner1.jpg')); ?>" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Banner Carousel</h5>
                        <p class="card-text">Atur dan kelola Banner Carousel pesantren.</p>
                        <div class="text-center">
                            <a href="<?php echo e(url('home-slider')); ?>" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ponpes-app\resources\views/admin/index.blade.php ENDPATH**/ ?>