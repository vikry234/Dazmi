@extends('layouts.layouts')

@section('content')
<style>
    .img-fluid.card-img-top {
        width: 100%;
        height: 220px;
    }

    .card-img-top {
        width: 100%;
        height: 200px;
        /* Tinggi gambar pada grid */
        object-fit: cover;
        /* Memastikan gambar mempertahankan aspek rasio */
    }


    @media screen and (max-width: 767px) {

        .col-xl-3,
        .col-lg-4 {
            flex: 0 0 50%;
            max-width: 50%;
        }
    }

    .zoomable {
        overflow: hidden;
        position: relative;
        display: inline-block;
    }

    .zoomable img {
        transition: transform 0.3s ease;
    }

    .zoomable:hover img {
        transform: scale(1.1);
    }

    @media screen and (min-width: 425) {
        .gbr {
            font-size: 10px;
        }
    }
</style>
<style>
    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        list-style: none;
        padding: 0;
    }

    .pagination li {
        margin-right: 5px;
        /* Atur jarak antar elemen paginasi */
    }

    .pagination li a {
        padding: 5px 10px;
        background-color: #ccc;
        /* Warna latar belakang */
        color: #000;
        /* Warna teks */
        text-decoration: none;
    }

    .pagination li.active a {
        background-color: #144191;
        /* Warna latar belakang saat aktif */
        color: #fff;
        /* Warna teks saat aktif */
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css" rel="stylesheet">


<section class="py-5">
    <div class="container-fluid">
        <div class="text-center">
            <h1 id="dazmi" style="color: #144171;" class="dazmi fw-bold">Gallery</h1>
        </div>
        <!-- SEKOLAH -->
        <div class="px-lg-5">
            <h3 class="fw-bold" style="color: #144171;">Kegiatan Santri</h3>
            <div class="row">
                @foreach ($photos as $photo)
                <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                    <div class="bg-white rounded shadow-sm">
                        <a href="{{ asset('/storage/photo/' . $photo->image) }}" data-lightbox="gallery" class="zoomable">
                            <img src="{{ asset('/storage/photo/' . $photo->image) }}" alt="" class="img-fluid card-img-top">
                        </a>
                        <div class="p-4">
                            <div class="d-flex align-items-center justify-content-center rounded-pill bg-light px-3 py-2 mt-4">
                                <h5 class="gbr">{{ $photo->judul }}</h5>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        {{ $photos->links('pagination::bootstrap-4') }}
</section>

<script>
    // Ini akan menerapkan Lightbox ke semua elemen yang memiliki atribut data-lightbox
    lightbox.option({
        'resizeDuration': 200,
        'wrapAround': true
    });
</script>

@endsection