@extends('layouts.layouts')

@section('content')
{{-- BERITA --}}
<style>
  a {
    text-decoration: none;
    color: #144171;
  }

  .img-fluid.card-img-top {
    width: 400px;
    height: 220px;
  }

  .card-img-top {
    width: 100%;
    height: 200px;
    /* Tinggi gambar pada grid */
    object-fit: cover;
    /* Memastikan gambar mempertahankan aspek rasio */
  }

  .card-box {
    position: relative;
    display: inline-block;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    /* Menambahkan transisi efek bayangan */
  }

  .card-box:hover {
    transform: scale(1.1);
    box-shadow: 0 0 50px rgba(0, 0, 0, 0.1);
    /* Menambahkan bayangan pada kotak kartu saat dihover */
  }
</style>
<style>
  .pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    list-style: none;
    padding: 0;
  }

  .pagination li {
    margin-right: 5px;
    /* Atur jarak antar elemen paginasi */
  }

  .pagination li a {
    padding: 5px 10px;
    background-color: #ccc;
    /* Warna latar belakang */
    color: #000;
    /* Warna teks */
    text-decoration: none;
  }

  .pagination li.active a {
    background-color: #144191;
    /* Warna latar belakang saat aktif */
    color: #fff;
    /* Warna teks saat aktif */
  }

  .konten-berita p:hover {
    color: blue;
    /* Warna teks saat dihover */
  }
</style>


<section id="berita" class="py-5" data-aos="zoom-in" style="margin-top: 100px;">
  <div class="container">
    <!-- Form pencarian -->
    <div class="row justify-content-center mb-4">
      <div class="col-md-6">
        <form action="{{ route('search') }}" method="GET">
          <div class="input-group">
            <input type="text" class="form-control" name="query" placeholder="Cari artikel...">
            <button style="background-color: #144171; color: white" class="btn btn-primary" type="submit">Cari</button>
          </div>
        </form>
      </div>
    </div>

    <div class="header-berita text-center">
      <h2 class="fw-bold" style="color: #144171;">BERITA KEGIATAN</h2>
    </div>

    <div class="row py-5">
      @foreach ($artikels as $item)
      <div class="col-lg-4">
        <div class="card-box border-2" data-lightbox="gallery" class="zoomable">
          <a href="/detail/{{ $item->slug }}">
            <img src="{{ asset('storage/artikel/' . $item->image) }}" class="img-fluid card-img-top" alt="">
          </a>
          <div class="konten-berita">
            <a href="/detail/{{ $item->slug }}">
              <h4 class="fw-bold mb-3">{{ $item->judul }}</h4>
            </a>
            <p class="mb-3 text-secondary">
              <i class="far fa-calendar-alt"></i> {{ $item->created_at }}
            </p>
            <p class="text-secondary">{{ Str::limit(strip_tags($item->desc), 100) }}</p>
            <a href="/detail/{{ $item->slug }}" class="text-decoration-none" style="color: #144171;">Selengkapnya</a>
          </div>
        </div>
      </div>
      @endforeach
    </div>
    {{ $artikels->links('pagination::bootstrap-4') }}
  </div>
</section>
{{-- BERITA --}}
@endsection