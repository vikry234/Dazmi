@extends('layouts.layouts')
@section('content')
<style>
    .sticky-top {
        padding-top: 25%;
        position: sticky;
    }

    #gasi {
        text-decoration: none;
    }
</style>
<section id="detail" style="margin-top: 100px;" class="py-5">
    <div class="container">
        <div class="row">
            <!-- Sisi kiri: Detail berita -->
            <div class="col-md-8">
                <div id="gasi" class="d-flex mb-3">
                    <a href="{{ route('home') }}">Home</a> / <a href="/berita">Berita</a> / {{ $artikel->judul }}
                </div>
                <img src="{{ asset('storage/artikel/' . $artikel->image) }}" class="img-fluid mb-3" alt="">
                <div class="konten-berita">
                    <p class="mb-3 text-secondary">{{ $artikel->created_at }}</p>
                    <h4 class="fw-bold mb-3">{{ $artikel->judul }}</h4>
                    <p class="text-secondary">{!! $artikel->desc !!}</p>
                </div>
            </div>
            <!-- Sisi kanan: Daftar berita lainnya -->
            <div class="col-md-4">
                <div class="sticky-top">
                    <h3 class="fst-italic">Berita Lainnya</h3>
                    <ul class="list-group">
                        <div class="position-sticky" style="top: 2rem;">
                            <div>
                                <ul class="list-unstyled">
                                    <li>
                                        <a class="d-flex flex-column flex-lg-row gap-3 align-items-start align-items-lg-center py-3 link-body-emphasis text-decoration-none border-top" href="#">
                                            <div class="col-lg-8">
                                                <img src="{{ asset('storage/artikel/' . $artikel->image) }}" class="img-fluid card-img-top" alt="">
                                                <h4 class="fw-bold mb-3">{{ $artikel->judul }}</h4>
                                                <p class="mb-3 text-secondary">{{ $artikel->created_at->format('d M Y') }}</p>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="d-flex flex-column flex-lg-row gap-3 align-items-start align-items-lg-center py-3 link-body-emphasis text-decoration-none border-top" href="#">
                                            <div class="col-lg-8">
                                                <h6 class="mb-0">Kegiatan Pentas seni</h6>
                                                <small class="text-body-secondary">Januar7 17, 2023</small>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="d-flex flex-column flex-lg-row gap-3 align-items-start align-items-lg-center py-3 link-body-emphasis text-decoration-none border-top" href="#">
                                            <div class="col-lg-8">
                                                <h6 class="mb-0">Informasi PPDB</h6>
                                                <small class="text-body-secondary">Januari 17, 2023</small>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                                <div class="text-center">
                                    <a href="/berita" class="btn btn-outline-primary">Berita Lainnya</a>
                                </div>
                            </div>
                        </div>
                    </ul>
                </div>
            </div>
        </div>
</section>
@endsection