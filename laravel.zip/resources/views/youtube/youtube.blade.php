@extends('layouts.layouts')

@section('content')
<style>
    .card-box {
        width: 100%;
        position: relative;
        display: inline-block;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        /* Menambahkan transisi efek bayangan */
    }
</style>
<style>
    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        list-style: none;
        padding: 0;
    }

    .pagination li {
        margin-right: 5px;
        /* Atur jarak antar elemen paginasi */
    }

    .pagination li a {
        padding: 5px 10px;
        background-color: #ccc;
        /* Warna latar belakang */
        color: #000;
        /* Warna teks */
        text-decoration: none;
    }

    .pagination li.active a {
        background-color: #144171;
        /* Warna latar belakang saat aktif */
        color: #fff;
        /* Warna teks saat aktif */
    }
</style>

<section id="berita" class="py-5" data-aos="zoom-in" style="margin-top: 100px;">
    <div class="container">
        <!-- Form pencarian -->
        <div class="row justify-content-center mb-4">
            <div class="col-md-6">
                <form action="{{ route('searchyt') }}" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" name="query" placeholder="Cari artikel...">
                        <button style="background-color: #144171; color: white" class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="header-berita text-center">
            <h2 class="fw-bold" style="color: #144171;">VIDEO KEGIATAN</h2>
        </div>

        <div class="row py-5">
            @foreach ($videos as $item)
            <div class="col-lg-4">
                <div class="card-box border-2">
                    <iframe width="100%" height="300" src="https://www.youtube.com/embed/{{ $item->youtube_code }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    <h4 class="fw-bold">{{ $item->judul }}</h4>
                    <p class="mb-3 text-secondary">{{ $item->created_at->format('d M Y') }}</p>
                    <p class="text-secondary">{{ Str::limit(strip_tags($item->desc), 100) }}</p>
                </div>
            </div>
            @endforeach
        </div>
        {{ $videos->links('pagination::bootstrap-4') }}
    </div>
</section>
{{-- BERITA --}}
@endsection